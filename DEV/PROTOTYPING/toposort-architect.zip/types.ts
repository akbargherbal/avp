
export enum StepType {
  INIT = 'INIT',
  FIND_SOURCES = 'FIND_SOURCES',
  ENQUEUE_SOURCE = 'ENQUEUE_SOURCE',
  DEQUEUE = 'DEQUEUE',
  ADD_TO_ORDER = 'ADD_TO_ORDER',
  EXAMINE_NEIGHBOR = 'EXAMINE_NEIGHBOR',
  DECREMENT_DEGREE = 'DECREMENT_DEGREE',
  CHECK_NEW_SOURCE = 'CHECK_NEW_SOURCE',
  ENQUEUE_NEW_SOURCE = 'ENQUEUE_NEW_SOURCE',
  COMPLETE = 'COMPLETE',
  CYCLE_DETECTED = 'CYCLE_DETECTED'
}

export interface NodePosition {
  x: number;
  y: number;
}

export interface GraphData {
  id: string;
  name: string;
  nodes: string[];
  edges: [string, string][];
  positions: Record<string, NodePosition>;
}

export interface DashboardBoundary {
  label: string;
  value: string | number;
  oldValue?: string | number;
  direction?: 'up' | 'down' | 'neutral';
}

export interface TopologicalSortStep {
  id: number;
  type: StepType;
  description: string;
  data: {
    visualization: {
      currentNode: string | null;
      queue: string[];
      topologicalOrder: string[];
      inDegrees: Record<string, number>;
      visitedNodes: string[];
      activeEdge?: { from: string; to: string };
      neighborNode?: string;
    };
    dashboard: {
      hero: string;
      heroMeta?: string;
      goal: string | number;
      logic: string;
      logicSub?: string;
      action: string;
      boundaries: DashboardBoundary[];
    };
  };
}
