
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { SAMPLE_GRAPHS } from './constants';
import { TopologicalSortStep, GraphData } from './types';
import { generateSteps } from './hooks/useTopologicalSort';
import Header from './components/Header';
import VisualizationPanel from './components/VisualizationPanel';
import StepsPanel from './components/StepsPanel';
import Modal from './components/Modal';

const App: React.FC = () => {
  const [selectedGraphId, setSelectedGraphId] = useState(SAMPLE_GRAPHS[0].id);
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1000);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);

  const graph = useMemo(() => SAMPLE_GRAPHS.find(g => g.id === selectedGraphId) || SAMPLE_GRAPHS[0], [selectedGraphId]);
  const steps = useMemo(() => generateSteps(graph), [graph]);
  const currentStep = steps[currentStepIdx] || steps[0];

  const handleNext = useCallback(() => {
    if (currentStepIdx < steps.length - 1) {
      setCurrentStepIdx(prev => prev + 1);
    } else {
      setIsPlaying(false);
    }
  }, [currentStepIdx, steps.length]);

  const handlePrev = useCallback(() => {
    if (currentStepIdx > 0) {
      setCurrentStepIdx(prev => prev - 1);
    }
  }, [currentStepIdx]);

  const handleReset = useCallback(() => {
    setCurrentStepIdx(0);
    setIsPlaying(false);
  }, []);

  useEffect(() => {
    let timer: number | undefined;
    if (isPlaying) {
      timer = window.setInterval(handleNext, playbackSpeed);
    }
    return () => clearInterval(timer);
  }, [isPlaying, handleNext, playbackSpeed]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch(e.key) {
        case 'ArrowRight': handleNext(); break;
        case 'ArrowLeft': handlePrev(); break;
        case 'r': case 'R': handleReset(); break;
        case ' ': e.preventDefault(); setIsPlaying(p => !p); break;
        case '?': setIsShortcutsOpen(true); break;
        case 'Escape': 
          setIsShortcutsOpen(false); 
          setIsInfoOpen(false);
          break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNext, handlePrev, handleReset]);

  return (
    <div id="app-root" className="flex h-screen w-full flex-col overflow-hidden bg-slate-900">
      <Header 
        currentIdx={currentStepIdx}
        totalSteps={steps.length}
        selectedGraphId={selectedGraphId}
        onSelectGraph={setSelectedGraphId}
        onNext={handleNext}
        onPrev={handlePrev}
        onReset={handleReset}
        isPlaying={isPlaying}
        onTogglePlay={() => setIsPlaying(!isPlaying)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
      />

      <main className="flex flex-1 items-center justify-center overflow-hidden p-4">
        <div className="flex h-full w-full max-w-7xl gap-4 overflow-hidden">
          <VisualizationPanel graph={graph} currentStep={currentStep} />
          <StepsPanel steps={steps} currentIdx={currentStepIdx} />
        </div>
      </main>

      {/* Modals */}
      <Modal isOpen={isShortcutsOpen} onClose={() => setIsShortcutsOpen(false)} title="Keyboard Shortcuts" maxWidth="max-w-md">
        <div className="space-y-4">
          <div className="flex justify-between items-center"><span className="text-slate-300 font-medium">Next Step</span><kbd className="kbd">→</kbd></div>
          <div className="flex justify-between items-center"><span className="text-slate-300 font-medium">Previous Step</span><kbd className="kbd">←</kbd></div>
          <div className="flex justify-between items-center"><span className="text-slate-300 font-medium">Play / Pause</span><kbd className="kbd">SPACE</kbd></div>
          <div className="flex justify-between items-center"><span className="text-slate-300 font-medium">Reset Algorithm</span><kbd className="kbd">R</kbd></div>
          <div className="flex justify-between items-center"><span className="text-slate-300 font-medium">Shortcuts Help</span><kbd className="kbd">?</kbd></div>
          <div className="flex justify-between items-center"><span className="text-slate-300 font-medium">Close Modal</span><kbd className="kbd">ESC</kbd></div>
        </div>
      </Modal>

      <Modal isOpen={isInfoOpen} onClose={() => setIsInfoOpen(false)} title="About Topological Sort">
        <div className="space-y-4 text-slate-300">
          <p>
            <strong className="text-blue-400">Topological Sort</strong> is a linear ordering of vertices such that for every directed edge (u, v), u comes before v in the ordering.
          </p>
          <h4 className="text-white font-bold">Kahn's Algorithm (BFS)</h4>
          <ol className="list-decimal pl-5 space-y-2">
            <li>Calculate in-degree for every vertex.</li>
            <li>Add all vertices with in-degree 0 to a queue.</li>
            <li>While queue is not empty:
              <ul className="list-disc pl-5 mt-1 text-sm text-slate-400">
                <li>Dequeue node <strong>u</strong> and add it to order.</li>
                <li>For each neighbor <strong>v</strong> of <strong>u</strong>, decrement in-degree.</li>
                <li>If <strong>v</strong>'s in-degree becomes 0, enqueue it.</li>
              </ul>
            </li>
            <li>If total nodes processed &lt; total vertices, the graph has a cycle.</li>
          </ol>
          <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700 mt-4">
            <h5 className="text-xs font-black text-slate-500 uppercase mb-2">Complexity</h5>
            <div className="grid grid-cols-2 gap-4">
              <div><p className="text-[10px] text-slate-400 uppercase">Time</p><p className="text-white font-mono">O(V + E)</p></div>
              <div><p className="text-[10px] text-slate-400 uppercase">Space</p><p className="text-white font-mono">O(V)</p></div>
            </div>
          </div>
        </div>
      </Modal>
      
      {/* Tiny floating info trigger for context */}
      <button 
        onClick={() => setIsInfoOpen(true)}
        className="fixed bottom-6 right-6 w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-2xl hover:bg-blue-500 transition-colors z-30"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01" />
        </svg>
      </button>
    </div>
  );
};

export default App;
