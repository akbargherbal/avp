
import { GraphData, StepType, TopologicalSortStep } from '../types';

export const generateSteps = (graph: GraphData): TopologicalSortStep[] => {
  const steps: TopologicalSortStep[] = [];
  let stepId = 0;

  const nodes = [...graph.nodes];
  const edges = [...graph.edges];
  const inDegrees: Record<string, number> = {};
  const adjacency: Record<string, string[]> = {};

  // Initialize
  nodes.forEach(n => {
    inDegrees[n] = 0;
    adjacency[n] = [];
  });

  edges.forEach(([u, v]) => {
    inDegrees[v]++;
    adjacency[u].push(v);
  });

  const pushStep = (type: StepType, desc: string, viz: any, dash: any) => {
    steps.push({
      id: stepId++,
      type,
      description: desc,
      data: {
        visualization: {
          currentNode: null,
          queue: [],
          topologicalOrder: [],
          inDegrees: { ...inDegrees },
          visitedNodes: [],
          ...viz
        },
        dashboard: {
          hero: 'INIT',
          goal: nodes.length,
          logic: 'START',
          action: 'INITIALIZING',
          boundaries: [],
          ...dash
        }
      }
    });
  };

  // Step 1: INIT
  pushStep(
    StepType.INIT,
    'Calculate initial in-degrees for all nodes in the graph.',
    {},
    { hero: 'START', logic: 'GRAPH', action: 'CALCULATE IN-DEGREES' }
  );

  // Step 2: FIND INITIAL SOURCES
  const queue: string[] = nodes.filter(n => inDegrees[n] === 0);
  pushStep(
    StepType.FIND_SOURCES,
    `Found ${queue.length} source nodes with in-degree = 0.`,
    { queue: [] },
    { 
      hero: queue.length.toString(), 
      heroMeta: 'SOURCES', 
      logic: 'SCAN', 
      action: 'IDENTIFY SOURCES',
      boundaries: [{ label: 'Sources', value: queue.length }]
    }
  );

  // Step 3: ENQUEUE INITIAL SOURCES
  queue.forEach((n, idx) => {
    const currentQueue = queue.slice(0, idx + 1);
    pushStep(
      StepType.ENQUEUE_SOURCE,
      `Add source node ${n} to the processing queue.`,
      { queue: currentQueue },
      { 
        hero: n, 
        logic: 'ENQUEUE', 
        action: 'ADD SOURCE TO QUEUE',
        boundaries: [{ label: 'Queue', value: currentQueue.length, direction: 'up' }]
      }
    );
  });

  const visited: string[] = [];
  const order: string[] = [];
  const activeQueue = [...queue];

  // Kahn's Core Loop
  while (activeQueue.length > 0) {
    const u = activeQueue.shift()!;
    
    // Dequeue
    pushStep(
      StepType.DEQUEUE,
      `Dequeue node ${u} from the queue.`,
      { currentNode: u, queue: [...activeQueue], topologicalOrder: [...order], visitedNodes: [...visited] },
      { 
        hero: u, 
        heroMeta: `#${order.length + 1}`,
        logic: 'DEQUEUE', 
        action: 'GET NEXT SOURCE',
        boundaries: [
          { label: 'Queue', value: activeQueue.length, direction: 'down' },
          { label: 'Order', value: order.length }
        ]
      }
    );

    // Add to Order
    order.push(u);
    visited.push(u);
    pushStep(
      StepType.ADD_TO_ORDER,
      `Add node ${u} to the topological order.`,
      { currentNode: u, queue: [...activeQueue], topologicalOrder: [...order], visitedNodes: [...visited] },
      { 
        hero: u, 
        heroMeta: 'READY',
        goal: nodes.length - order.length,
        logic: 'RECORD', 
        action: 'UPDATE ORDER',
        boundaries: [
          { label: 'Unprocessed', value: nodes.length - order.length, direction: 'down' },
          { label: 'Order', value: order.length, direction: 'up' }
        ]
      }
    );

    // Examine Neighbors
    const neighbors = adjacency[u];
    for (const v of neighbors) {
      pushStep(
        StepType.EXAMINE_NEIGHBOR,
        `Examine outgoing edge from ${u} to ${v}.`,
        { currentNode: u, activeEdge: { from: u, to: v }, neighborNode: v, queue: [...activeQueue], topologicalOrder: [...order], visitedNodes: [...visited] },
        { 
          hero: v, 
          heroMeta: `FROM ${u}`,
          logic: 'LINK', 
          action: 'CHECK DEPENDENCY',
          boundaries: [
            { label: 'From', value: u },
            { label: 'To', value: v },
            { label: 'In-Deg', value: inDegrees[v] }
          ]
        }
      );

      const oldDeg = inDegrees[v];
      inDegrees[v]--;
      pushStep(
        StepType.DECREMENT_DEGREE,
        `Decrement in-degree of ${v} because dependency ${u} is processed.`,
        { currentNode: u, activeEdge: { from: u, to: v }, neighborNode: v, queue: [...activeQueue], topologicalOrder: [...order], visitedNodes: [...visited] },
        { 
          hero: v, 
          heroMeta: `${oldDeg}→${inDegrees[v]}`,
          logic: 'REDUCE', 
          action: 'DECREMENT IN-DEGREE',
          boundaries: [
            { label: 'Before', value: oldDeg },
            { label: 'After', value: inDegrees[v], direction: 'down' }
          ]
        }
      );

      if (inDegrees[v] === 0) {
        pushStep(
          StepType.CHECK_NEW_SOURCE,
          `In-degree of ${v} is now 0. It is ready for processing.`,
          { currentNode: u, neighborNode: v, queue: [...activeQueue], topologicalOrder: [...order], visitedNodes: [...visited] },
          { 
            hero: v, 
            logic: 'READY', 
            logicSub: 'IN-DEG = 0',
            action: 'VALIDATE NEW SOURCE',
            boundaries: [{ label: 'Ready', value: 'YES' }]
          }
        );

        activeQueue.push(v);
        pushStep(
          StepType.ENQUEUE_NEW_SOURCE,
          `Enqueue ${v} as a new source for future processing.`,
          { currentNode: u, queue: [...activeQueue], topologicalOrder: [...order], visitedNodes: [...visited] },
          { 
            hero: v, 
            logic: 'ENQUEUE', 
            action: 'ADD TO QUEUE',
            boundaries: [{ label: 'Queue', value: activeQueue.length, direction: 'up' }]
          }
        );
      }
    }
  }

  // Completion / Cycle Check
  if (order.length === nodes.length) {
    pushStep(
      StepType.COMPLETE,
      'Topological sort completed successfully! All nodes processed.',
      { queue: [], topologicalOrder: [...order], visitedNodes: [...visited] },
      { hero: 'DONE', logic: 'PASS', action: 'ALGORITHM FINISHED', boundaries: [{ label: 'Status', value: 'VALID DAG' }] }
    );
  } else {
    pushStep(
      StepType.CYCLE_DETECTED,
      'Cycle detected! Some nodes were never processed because they remain in a dependency loop.',
      { queue: [], topologicalOrder: [...order], visitedNodes: [...visited] },
      { hero: 'FAIL', logic: 'CYCLE', action: 'TOPOLOGICAL SORT IMPOSSIBLE', boundaries: [{ label: 'Status', value: 'INVALID' }] }
    );
  }

  return steps;
};
