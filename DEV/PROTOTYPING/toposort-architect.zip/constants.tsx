
import { GraphData } from './types';

export const SAMPLE_GRAPHS: GraphData[] = [
  {
    id: 'linear',
    name: 'Linear Dependencies',
    nodes: ['A', 'B', 'C', 'D'],
    edges: [['A', 'B'], ['B', 'C'], ['C', 'D']],
    positions: {
      'A': { x: 100, y: 300 },
      'B': { x: 300, y: 300 },
      'C': { x: 500, y: 300 },
      'D': { x: 700, y: 300 }
    }
  },
  {
    id: 'diamond',
    name: 'Diamond Pattern',
    nodes: ['A', 'B', 'C', 'D'],
    edges: [['A', 'B'], ['A', 'C'], ['B', 'D'], ['C', 'D']],
    positions: {
      'A': { x: 100, y: 300 },
      'B': { x: 400, y: 150 },
      'C': { x: 400, y: 450 },
      'D': { x: 700, y: 300 }
    }
  },
  {
    id: 'courses',
    name: 'Course Prerequisites',
    nodes: ['CS1', 'CS2', 'CS3', 'PHY1', 'PHY2', 'CHM1'],
    edges: [
      ['CS1', 'CS2'], ['CS2', 'CS3'],
      ['CS1', 'PHY1'], ['PHY1', 'PHY2'], ['CS2', 'PHY2'],
      ['PHY1', 'CHM1']
    ],
    positions: {
      'CS1': { x: 100, y: 150 },
      'CS2': { x: 350, y: 150 },
      'CS3': { x: 600, y: 150 },
      'PHY1': { x: 200, y: 400 },
      'PHY2': { x: 450, y: 400 },
      'CHM1': { x: 100, y: 550 }
    }
  },
  {
    id: 'cyclic',
    name: 'Cyclic (Invalid)',
    nodes: ['A', 'B', 'C'],
    edges: [['A', 'B'], ['B', 'C'], ['C', 'A']],
    positions: {
      'A': { x: 400, y: 150 },
      'B': { x: 600, y: 450 },
      'C': { x: 200, y: 450 }
    }
  }
];

export const COLORS = {
  unvisited: '#64748b',
  inQueue: '#3b82f6',
  processing: '#fbbf24',
  completed: '#34d399',
  edgeDefault: '#475569',
  edgeActive: '#f59e0b'
};
