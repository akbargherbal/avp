
import React, { useRef, useEffect } from 'react';
import { TopologicalSortStep } from '../types';
import Dashboard from './Dashboard';

interface StepsPanelProps {
  steps: TopologicalSortStep[];
  currentIdx: number;
}

const StepsPanel: React.FC<StepsPanelProps> = ({ steps, currentIdx }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const currentStep = steps[currentIdx];

  useEffect(() => {
    const activeItem = document.getElementById('step-current');
    if (activeItem && scrollRef.current) {
      activeItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [currentIdx]);

  return (
    <div id="panel-steps" className="flex w-1/3 select-none flex-col overflow-hidden rounded-xl border border-slate-700 bg-slate-800 shadow-2xl">
      <div className="flex flex-shrink-0 items-center justify-between px-5 pt-5 mb-4">
        <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400">Step History</h2>
        <div className="text-[10px] font-black bg-slate-700 px-2 py-1 rounded text-slate-300">
          STEP {currentIdx + 1} / {steps.length}
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="h-[240px] flex-shrink-0">
          <Dashboard step={currentStep} />
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2 bg-slate-900/50">
          {steps.map((step, idx) => (
            <div 
              key={step.id}
              id={idx === currentIdx ? 'step-current' : undefined}
              className={`p-3 rounded-lg border transition-all ${
                idx === currentIdx 
                  ? 'bg-blue-600/20 border-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.15)]' 
                  : idx < currentIdx 
                    ? 'bg-slate-800/40 border-slate-700 opacity-60' 
                    : 'bg-transparent border-transparent opacity-30'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                  idx === currentIdx ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400'
                }`}>
                  {step.type}
                </span>
                <span className="text-[9px] font-bold text-slate-600">#{idx + 1}</span>
              </div>
              <p className={`text-xs leading-relaxed ${idx === currentIdx ? 'text-slate-100' : 'text-slate-400'}`}>
                {step.description}
              </p>
            </div>
          ))}
        </div>

        <div id="panel-step-description" className="flex-shrink-0 border-t border-slate-700 bg-gradient-to-br from-slate-700/60 to-slate-800/60 p-4">
           <div className="flex items-start gap-3">
             <div className="bg-amber-400 text-black text-[10px] font-black p-1 rounded-md shrink-0 mt-1">
               {currentStep.type}
             </div>
             <p className="text-sm font-bold leading-snug text-white">
               {currentStep.description}
             </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default StepsPanel;
