
import React from 'react';
import { TopologicalSortStep } from '../types';

interface DashboardProps {
  step: TopologicalSortStep;
}

const Dashboard: React.FC<DashboardProps> = ({ step }) => {
  const { dashboard } = step.data;

  return (
    <div className="w-full h-full bg-slate-600 grid grid-cols-[2fr_1fr] grid-rows-[1fr_48px_32px] gap-[1px] overflow-hidden">
      {/* ZONE 1: PRIMARY FOCUS */}
      <div className="relative col-start-1 row-start-1 row-end-3 bg-slate-900 flex items-center justify-center pb-12 overflow-hidden">
        <span className="absolute top-1.5 left-2.5 text-[10px] font-extrabold uppercase text-amber-600 z-20">Focus</span>
        {dashboard.heroMeta && (
          <span className="absolute top-1.5 right-2.5 text-[10px] font-extrabold uppercase text-amber-600 z-20">{dashboard.heroMeta}</span>
        )}
        <div className="text-[80px] font-black leading-[0.8] tracking-tighter text-amber-400 z-10 drop-shadow-[0_0_15px_rgba(251,191,36,0.2)]">
          {dashboard.hero}
        </div>

        {/* ZONE 5: BOUNDARIES (CONTEXT) */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-slate-900/95 backdrop-blur-sm border-t border-white/10 z-20 flex items-stretch">
          {dashboard.boundaries.map((b, i) => (
            <div key={i} className="flex-1 flex flex-col items-center justify-center border-r border-white/5 last:border-r-0">
              <span className="text-[8px] font-bold text-slate-500 uppercase leading-none mb-1">{b.label}</span>
              <div className="text-[14px] font-bold text-slate-100 flex items-center gap-1">
                {b.oldValue !== undefined && <span className="text-[0.75em] opacity-40 line-through">{b.oldValue}</span>}
                <span className={b.direction === 'up' ? 'text-emerald-400' : b.direction === 'down' ? 'text-rose-400' : ''}>
                  {b.value}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ZONE 2: GOAL */}
      <div className="relative bg-slate-800 flex items-center justify-center overflow-hidden">
        <span className="absolute top-1.5 left-2.5 text-[10px] font-extrabold uppercase text-emerald-600 z-20">Remaining</span>
        <div className="text-[44px] font-black text-emerald-400 pt-2 drop-shadow-[0_0_10px_rgba(52,211,153,0.1)]">
          {dashboard.goal}
        </div>
      </div>

      {/* ZONE 3: LOGIC */}
      <div className="relative bg-blue-600 flex overflow-hidden">
        <div 
          className="flex items-center justify-center px-1 bg-black/25 border-r border-white/20"
          style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
        >
          <span className="text-[11px] font-black text-white tracking-widest uppercase shadow-white/40">Logic</span>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center text-center px-2">
          <div className="text-sm font-black text-white leading-tight uppercase">{dashboard.logic}</div>
          {dashboard.logicSub && (
            <div className="text-[10px] font-bold text-blue-200 uppercase mt-0.5">{dashboard.logicSub}</div>
          )}
        </div>
      </div>

      {/* ZONE 4: ACTION */}
      <div className="col-start-1 col-end-3 bg-[#00574b] flex items-center justify-center overflow-hidden">
        <div className="text-[10px] font-bold text-slate-300 uppercase tracking-wider text-center px-4">
          {dashboard.action}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
