
import React, { useState } from 'react';
import { SAMPLE_GRAPHS } from '../constants';

interface HeaderProps {
  currentIdx: number;
  totalSteps: number;
  selectedGraphId: string;
  onSelectGraph: (id: string) => void;
  onNext: () => void;
  onPrev: () => void;
  onReset: () => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onOpenShortcuts: () => void;
}

const Header: React.FC<HeaderProps> = ({
  currentIdx, totalSteps, selectedGraphId, onSelectGraph,
  onNext, onPrev, onReset, isPlaying, onTogglePlay, onOpenShortcuts
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const currentGraph = SAMPLE_GRAPHS.find(g => g.id === selectedGraphId);

  return (
    <header id="app-header" className="border-b border-slate-700 bg-slate-800 px-4 py-3 shrink-0">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-lg font-black text-white leading-none">TopoSort Architect</h1>
            <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">Kahn's BFS Method</p>
          </div>
          
          <div className="relative border-l border-slate-600 pl-4">
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-2 rounded-lg bg-slate-700 px-3 py-1.5 hover:bg-slate-600 transition-colors"
            >
              <span className="text-sm font-bold text-white">{currentGraph?.name}</span>
              <svg className={`w-4 h-4 text-slate-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {isDropdownOpen && (
              <div className="absolute left-4 top-full mt-2 w-56 rounded-md bg-slate-800 border border-slate-700 shadow-2xl z-50">
                <div className="py-1">
                  {SAMPLE_GRAPHS.map(g => (
                    <button
                      key={g.id}
                      onClick={() => { onSelectGraph(g.id); setIsDropdownOpen(false); onReset(); }}
                      className={`block w-full text-left px-4 py-2 text-sm ${g.id === selectedGraphId ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`}
                    >
                      {g.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-900 rounded-lg p-1 border border-slate-700 mr-2">
            <button 
              onClick={onTogglePlay} 
              className={`p-1.5 rounded-md transition-colors ${isPlaying ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
            >
              {isPlaying ? (
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>
              ) : (
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              )}
            </button>
          </div>

          <button onClick={onReset} className="flex items-center gap-2 rounded-lg bg-slate-700 px-3 py-2 text-sm font-bold text-white hover:bg-slate-600">
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" />
            </svg>
            Reset
          </button>
          
          <button onClick={onPrev} disabled={currentIdx === 0} className="flex items-center gap-2 rounded-lg bg-slate-700 px-3 py-2 text-sm font-bold text-white hover:bg-slate-600 disabled:opacity-30 disabled:cursor-not-allowed">
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <polygon points="19 20 9 12 19 4 19 20" /><line x1="5" x2="5" y1="19" y2="5" />
            </svg>
            Back
          </button>

          <button onClick={onNext} disabled={currentIdx >= totalSteps - 1} className="flex items-center gap-4 rounded-lg bg-emerald-500 px-5 py-2 text-sm font-black text-black hover:bg-emerald-400 disabled:bg-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed transition-all">
            <span>Next Step</span>
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
              <path d="M9 18l6-6-6-6" />
            </svg>
          </button>

          <button onClick={onOpenShortcuts} className="p-2 rounded-lg bg-slate-700 text-slate-400 hover:text-white transition-colors">
             <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
               <rect width="20" height="16" x="2" y="4" rx="2" ry="2" /><path d="M6 8h.001" /><path d="M10 8h.001" /><path d="M14 8h.001" /><path d="M18 8h.001" /><path d="M8 12h.001" /><path d="M12 12h.001" /><path d="M16 12h.001" /><path d="M7 16h10" />
             </svg>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
