
import React, { useMemo } from 'react';
import { GraphData, TopologicalSortStep } from '../types';
import { COLORS } from '../constants';

interface VisualizationPanelProps {
  graph: GraphData;
  currentStep: TopologicalSortStep;
}

const VisualizationPanel: React.FC<VisualizationPanelProps> = ({ graph, currentStep }) => {
  const { 
    currentNode, 
    queue, 
    topologicalOrder, 
    inDegrees, 
    activeEdge, 
    neighborNode 
  } = currentStep.data.visualization;

  const getNodeColor = (nodeId: string) => {
    if (nodeId === currentNode) return COLORS.processing;
    if (nodeId === neighborNode) return '#fb7185'; // Rose-400 for neighbor being examined
    if (topologicalOrder.includes(nodeId)) return COLORS.completed;
    if (queue.includes(nodeId)) return COLORS.inQueue;
    return COLORS.unvisited;
  };

  const isEdgeActive = (u: string, v: string) => {
    return activeEdge?.from === u && activeEdge?.to === v;
  };

  // Calculate bounds to center the graph better if needed, 
  // but for now, we use a structured grid.
  const gridPattern = useMemo(() => (
    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1"/>
    </pattern>
  ), []);

  return (
    <div id="panel-visualization" className="flex flex-[3] flex-col overflow-hidden rounded-xl border border-slate-700 bg-slate-900 shadow-2xl relative">
      {/* Header / Legend */}
      <div className="flex flex-shrink-0 items-center justify-between border-b border-slate-800 bg-slate-800/50 px-5 py-3 backdrop-blur-md z-10">
        <div>
          <h2 className="text-sm font-black uppercase tracking-widest text-white">System Architecture</h2>
          <p className="text-[10px] text-slate-500 font-bold uppercase">Node Dependency Mapping</p>
        </div>
        <div className="flex gap-4">
          {[
            { color: COLORS.unvisited, label: 'Idle' },
            { color: COLORS.inQueue, label: 'Queued' },
            { color: COLORS.processing, label: 'Focus' },
            { color: COLORS.completed, label: 'Solved' }
          ].map(item => (
            <div key={item.label} className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full shadow-[0_0_5px_rgba(255,255,255,0.1)]" style={{ backgroundColor: item.color }}></div>
              <span className="text-[10px] font-bold text-slate-500 uppercase">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Graph Canvas */}
      <div className="flex-1 relative overflow-hidden group">
        <div className="absolute inset-0 pointer-events-none transition-opacity duration-500 opacity-40 group-hover:opacity-100">
           <svg width="100%" height="100%">
             <rect width="100%" height="100%" fill="url(#grid)" />
           </svg>
        </div>

        <div className="h-full w-full overflow-auto custom-scrollbar p-8 flex items-center justify-center">
          <svg width="800" height="600" className="flex-shrink-0 drop-shadow-2xl" style={{ minWidth: '800px' }}>
            <defs>
              {gridPattern}
              <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="28" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill={COLORS.edgeDefault} className="opacity-40" />
              </marker>
              <marker id="arrowhead-active" markerWidth="12" markerHeight="9" refX="28" refY="4.5" orient="auto">
                <polygon points="0 0, 12 4.5, 0 9" fill={COLORS.edgeActive} />
              </marker>
            </defs>

            {/* Edges Layer */}
            {graph.edges.map(([u, v], i) => {
              const start = graph.positions[u];
              const end = graph.positions[v];
              const active = isEdgeActive(u, v);
              const isRelevant = u === currentNode || v === currentNode || u === neighborNode || v === neighborNode;

              return (
                <g key={`edge-group-${i}`}>
                  {active && (
                    <line
                      x1={start.x} y1={start.y}
                      x2={end.x} y2={end.y}
                      stroke={COLORS.edgeActive}
                      strokeWidth={8}
                      className="opacity-20 animate-pulse"
                    />
                  )}
                  <line
                    x1={start.x} y1={start.y}
                    x2={end.x} y2={end.y}
                    stroke={active ? COLORS.edgeActive : COLORS.edgeDefault}
                    strokeWidth={active ? 3 : 1.5}
                    strokeDasharray={active ? "none" : "4 2"}
                    markerEnd={active ? "url(#arrowhead-active)" : "url(#arrowhead)"}
                    className={`transition-all duration-500 ${!active && !isRelevant && currentNode ? 'opacity-10' : 'opacity-100'}`}
                  />
                </g>
              );
            })}

            {/* Nodes Layer */}
            {graph.nodes.map((node) => {
              const pos = graph.positions[node];
              const isFocus = node === currentNode;
              const isNeighbor = node === neighborNode;
              const isDone = topologicalOrder.includes(node);
              const isInactive = currentNode && !isFocus && !isNeighbor && !isDone && !queue.includes(node);
              
              const color = getNodeColor(node);
              const inDeg = inDegrees[node] ?? 0;
              
              return (
                <g 
                  key={node} 
                  className={`transition-all duration-500 ${isInactive ? 'opacity-20 scale-95 grayscale-[0.5]' : 'opacity-100'}`}
                >
                  {/* Subtle outer ring for active nodes */}
                  {(isFocus || isNeighbor) && (
                    <circle
                      cx={pos.x} cy={pos.y} r="32"
                      fill="none"
                      stroke={color}
                      strokeWidth="1"
                      className="animate-ping opacity-20"
                    />
                  )}
                  
                  {/* Main Node Body */}
                  <circle
                    cx={pos.x} cy={pos.y} r="24"
                    fill={color}
                    stroke={isFocus ? '#ffffff' : '#1e293b'}
                    strokeWidth={isFocus ? 3 : 2}
                    className="shadow-xl"
                    filter={isFocus ? "url(#glow)" : ""}
                  />

                  {/* Node Label */}
                  <text
                    x={pos.x} y={pos.y}
                    textAnchor="middle" dy=".3em"
                    fill={isDone ? '#064e3b' : isFocus ? '#000000' : '#ffffff'}
                    className="font-black text-xs select-none tracking-tight"
                  >
                    {node}
                  </text>

                  {/* In-Degree Counter (Badge) */}
                  {!isDone && (
                    <g transform={`translate(${pos.x + 18}, ${pos.y - 18})`}>
                      <circle r="9" fill="#0f172a" stroke={inDeg === 0 ? COLORS.completed : '#334155'} strokeWidth="1" />
                      <text
                        textAnchor="middle" dy=".3em"
                        fill={inDeg === 0 ? COLORS.completed : '#94a3b8'}
                        className="font-black text-[9px] select-none"
                      >
                        {inDeg}
                      </text>
                    </g>
                  )}

                  {/* Completion Mark */}
                  {isDone && (
                    <g transform={`translate(${pos.x + 18}, ${pos.y - 18})`}>
                      <circle r="9" fill={COLORS.completed} />
                      <path 
                        d="M -4 0 L -1 3 L 4 -3" 
                        fill="none" 
                        stroke="#064e3b" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                      />
                    </g>
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* State Overlays: Refined Layout */}
        <div className="absolute bottom-6 left-6 right-6 grid grid-cols-2 gap-6 pointer-events-none">
          {/* Queue Monitor */}
          <div className="bg-slate-800/60 backdrop-blur-xl p-4 rounded-xl border border-white/5 shadow-2xl ring-1 ring-black/20">
            <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
              <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em]">Queue Pipeline</h4>
              <span className="text-[10px] font-bold text-slate-500">{queue.length} NODES</span>
            </div>
            <div className="flex gap-2 min-h-[32px] overflow-x-auto pb-1 custom-scrollbar">
              {queue.length === 0 ? (
                <span className="text-[10px] font-medium text-slate-600 uppercase tracking-widest italic">Idle</span>
              ) : (
                queue.map((q, i) => (
                  <div key={i} className="flex-shrink-0 w-8 h-8 rounded bg-blue-600 flex items-center justify-center font-black text-xs text-white shadow-lg ring-1 ring-white/10 animate-in fade-in slide-in-from-left-2">
                    {q}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Result Sequence */}
          <div className="bg-slate-800/60 backdrop-blur-xl p-4 rounded-xl border border-white/5 shadow-2xl ring-1 ring-black/20">
            <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
              <h4 className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em]">Topological Stream</h4>
              <span className="text-[10px] font-bold text-slate-500">{topologicalOrder.length} RESOLVED</span>
            </div>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {topologicalOrder.length === 0 ? (
                <span className="text-[10px] font-medium text-slate-600 uppercase tracking-widest italic">Waiting...</span>
              ) : (
                topologicalOrder.map((o, i) => (
                  <div key={i} className="flex-shrink-0 w-8 h-8 rounded bg-emerald-600 flex items-center justify-center font-black text-xs text-white shadow-lg ring-1 ring-white/10 animate-in zoom-in-50">
                    {o}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VisualizationPanel;
